$(document).ready(() => {
    $(".dropdown-menu li input").click((res) => {
        let placeholder = res.target.dataset.placeholder;
        $('#placeholder').text(`${placeholder}`);
        $('.dropdown-toggle').removeClass('show');
        $('.dropdown-menu').removeClass('show');
    });

    $(".inputForm").on('input', function () {
        setTimeout(() => {
            $('#save-popup').removeClass('none');
            setTimeout(() => $('#save-popup').removeClass('hidden'), 800);
        }, 500);
    });

    $('#resetForm').click(function () {
        $("#formSave")[0].reset();
        $('#placeholder').text($('#placeholder').data('titleselect'))

        setTimeout(() => {
            $('#save-popup').addClass('hidden');
            setTimeout(() => $('#save-popup').addClass('none'), 800);
        }, 500);
    });
});
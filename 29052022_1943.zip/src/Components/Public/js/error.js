$(document).ready(() => {
    $('#buttonBack').click(() => {
        return window.history.back();
    }); 
});
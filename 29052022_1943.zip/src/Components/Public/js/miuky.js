console.log(`
███╗   ███╗██╗██╗   ██╗██╗  ██╗██╗   ██╗
████╗ ████║██║██║   ██║██║ ██╔╝╚██╗ ██╔╝
██╔████╔██║██║██║   ██║█████╔╝  ╚████╔╝ 
██║╚██╔╝██║██║██║   ██║██╔═██╗   ╚██╔╝  
██║ ╚═╝ ██║██║╚██████╔╝██║  ██╗   ██║   
╚═╝     ╚═╝╚═╝ ╚═════╝ ╚═╝  ╚═╝   ╚═╝   
                                        

Creator: Pedrovisk#0001
Discord: https://discord.com/invite/KJdhbH8CbD`)

// Loading Screen
$(window).on('load', () => {
    if (!navigator.cookieEnabled) {
        alert("[MIUKY] Enable Cookies");
        return window.location.reload();
    };

    setTimeout(() => {
        $('#loading').css({ 'opacity': '0' });
        setTimeout(() => {
            $('#loading').css({ 'display': 'none' });
        }, 1000);
    }, 1000);
});

// LOL :>
$(document).on('mousedown', (event) => {
    if (event.button === 2 || event.button === 3) {
        alert('[MIUKY] Press OK!');
    }
})

// Document Loaded
$(document).ready(() => {
    $('.button-navbar').click(() => {
        $('.animated-icon').toggleClass('open');
    });

    // Consent Popup
    if (!localStorage.getItem('MiukyConsent')) {
        setTimeout(() => {
            $('#consent-popup').removeClass('none');
            setTimeout(() => $('#consent-popup').removeClass('hidden'), 300);
        }, 2000);
    }

    $('#consent-okay').click(() => {
        localStorage.setItem('MiukyConsent', true);

        $('#consent-popup').addClass('hidden');
        setTimeout(() => $('#consent-popup').addClass('none'), 1000);
    });
});




$(document).ready(() => {
    $('[data-mdb-toggle="tooltip"]').tooltip();
});